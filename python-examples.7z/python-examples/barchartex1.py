import matplotlib.pyplot as plt
import pandas as pd
#months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
#sales = [23, 45, 56, 78, 213, 45, 78, 89, 99, 100, 101, 130]

df = pd.read_csv("sales11.csv")

plt.title("Sales Report")
plt.xlabel("Months")
plt.ylabel("Sales")

plt.bar(df.month,df.sales)
#plt.barh(months,sales)

plt.show()