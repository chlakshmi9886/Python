str1 = ''' Hello Venkat
How are you doing?
Hope practice going well'''

print(str1)
str = "Python strings"

print(str[0])
print(str[0:9])
for i in str:
	print(i)

#immutability
str2 = "Hello"
print(str2[0])
#str2[0]="X"
print(str2)


#how to find methods of a class
# we can find methods by using dir(Class name)

print(dir(str))
print(str2.count('l'))
print(len(str2))

lang = "python programming language"
ooplang = lang.replace('programming','oop programming')
print(lang)
print(ooplang)
print(id(lang))
print(id(ooplang))

s = 'python, programming, language'
n=s.split(',')
m=s.split()
print('before split: ' , s)
print('after split', n)
print(m)

course = "this is python         "
print(len(course))
print(course.strip())
print(len(course.strip()))