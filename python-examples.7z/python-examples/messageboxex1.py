import streamlit as st
import time as t
import datetime as dt


st.success("Operation submitted successfully")
st.info("information box")
st.warning("Warning message")
st.error("Error message")
#st.exception("Exception message")

#clock
st.title("Time clock")

#n=dt.datetime.now().strftime("%H:%M:%S")
#st.markdown(n)
#t.sleep(1)
#st.rerun()


#counter

st.title("Counter")
if "count" not in st.session_state:
	st.session_state.count = 0

if st.button("Increment"):
	st.session_state.count = st.session_state.count + 1

st.write(f"Count : {st.session_state.count}")


#progress bar

st.title("Progress bar")
c = st.progress(0)
for i in range(0,100):
	c.progress(i+1)
	t.sleep(0.05)


st.write("Finished")


