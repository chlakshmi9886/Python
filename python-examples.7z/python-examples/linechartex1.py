import matplotlib.pyplot as plt

x=[5,6]
y=[5,6]

plt.plot(x,y)
plt.show()



