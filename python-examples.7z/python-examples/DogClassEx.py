class DogClassEx:
    species = "Canin"
    def __init__(self, name, age):
        self.name = name#if we comment name and create object with name then we are getting attribute error.
        self.age = age
		
    def __str__(self): # something like toString() method
        return f"{self.name} is {self.age} years old."
		
dog1 = DogClassEx("Bunny", 3)
dog2 = DogClassEx("Charlie", 5)

print(dog1)
print(dog2)

print(dog1.name)
print(dog1.age)
print(DogClassEx.species)
dog1.species = "Nacin"
dog1.name="Sunny"
print(dog1.name)
print(dog2.name)
print(dog2.age)
print(dog1.species)
print(dog2.species)
DogClassEx.species="Raja"
print("dog1::",dog1.species)
print("dog2::",dog2.species)
