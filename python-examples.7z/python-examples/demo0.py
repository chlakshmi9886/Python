print("Hellow World!")
print(111.002)
print("111")