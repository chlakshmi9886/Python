import streamlit as st
import pandas as pd
f= st.file_uploader("Upload your file", type=["CSV"])

if f is not None:
	df = pd.read_csv(f)
	st.write(df)
	st.dataframe(df)


img = st.file_uploader("Upload file", type=["jpeg","jpg","png"])
if img is not None:
	st.write(img)