from functools import reduce

s = lambda a: a*a

x=s(4)
print(x)

sum = lambda a,b: a+b

y = sum(10,20)
print(f"Sum of two numbers {y}")


# print 1 to 10 numbers

ran = lambda d : print(d)

for l in range(1,10):
	ran(l)

#map function
with_out_gst = [100,200,300,400]
with_gst = map(lambda x:x+20, with_out_gst)
l = list(with_gst)
print(l)
print(with_out_gst)


#map function another example
print("Map function example---------")
sal = [50000,65000,70000,43000,32000]
print("Salary without bonus: ",sal)

print("find employees whose sal is below or equal to 50000 then apply 20% hike")
sal_withbonus = map(lambda x: x+(x*20)/100, filter(lambda x: x <= 50000, sal))
empsal = list(sal_withbonus)
print(f"Salary with bonus {empsal}")

#reduce function
print("reduce function example---------------------")
red = reduce(lambda x,y : x+y, [1,2,3,4,5])
print(red)

