import addsub

def mul(x,y):
	return x*y


mu = mul(addsub.add(10,20),addsub.sub(20,10))
print(f"multiplication of {addsub.add(10,20)} and {addsub.sub(20,10)} is {mu}")

print(addsub.v)
