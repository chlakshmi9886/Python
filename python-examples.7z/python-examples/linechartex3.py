import matplotlib.pyplot as plt

x=[1,2,3,4]
y=[1,4,9,16]
z=[1,8,27,64]

plt.title("Squares and Qubes")
plt.xlabel("numbers")
plt.ylabel("squares and qubes")

plt.plot(x,y,marker='*')
plt.plot(x,z,marker='*')

plt.show()