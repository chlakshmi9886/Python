import matplotlib.pyplot as plt
data = [12, 15, 13, 20, 19, 20, 11, 19, 11, 12, 19, 13, 15, 16, 18, 13]
plt.xlabel("X")
plt.ylabel("Y")

plt.title("Histogram Plot")

plt.hist(data, bins=20)
plt.show()