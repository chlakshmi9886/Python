def product(product, price):
	print("Product is: ",product)
	print(product, " price is ",price, "$")

product(price=200.45, product="Samsung")

def prod_pen(product, price=40):
	print("cost of ", product, "is ",price)

prod_pen(product="Parker Pen")

def prod_pencil(product, price=5):
	print("cost of ", product, "is ",price)

prod_pencil("Doms Pencil", 8)
prod_pencil("Nataraj Pencil")
prod_pencil("Venkat Pencil", price=9)
prod_pencil(product="Thiru Pencil", price=8)

def var_args(*x):
	print(x)

var_args(10,20,30)
var_args(1,2,3,4,5,6,10,20,30)
var_args(25)
var_args(100,30)



#Lambda function

add = lambda d,e: d+e

sum = add(2,3)

print(sum)


mu=lambda x,y: x*y

print(mu(2,3))


