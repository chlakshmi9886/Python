n = int(input("Enter number"))

if n > 0:
	print("positive number")
else:
	print ("negative number")