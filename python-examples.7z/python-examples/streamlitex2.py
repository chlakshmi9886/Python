
import streamlit as st

name = st.text_input("Enter your name")

st.write("your name is : ",name)

st.title("Streamlit examples")
st.header("Header")
st.subheader("Sub title")
st.write("Hello World Example!")

#creating variables and display them on browser
a=10
b=20
st.write(a)
st.write(b)
st.write("Sum of ", a, " and ", b, "is ", (a+b))

i = 10
fl=10.055
s = "Daniel"

st.write(i, fl, s)