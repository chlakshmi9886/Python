import streamlit as st
import yfinance as yf
import time

st.title("Live finance")

symbols=["AAPL","GOOGL"]

symbol = st.selectbox("Select Stock Symbol", options=symbols)

placeholder = st.empty()

if symbol:
	while True:
		data = yf.download(
			tickers = symbol,
			period="1d",
			interval="1m"
		)
		placeholder.line_chart(data["Close"])
		time.sleep(60)