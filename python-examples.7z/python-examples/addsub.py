v = 500

def add(*x):
	sum = 0 
	for y in x:	
		sum += y
	return sum

sum = add(10,20)

print(sum)

def sub(x,y):
	return x - y

print(sub(20,10))