# palindrom program in python using while loop

n = int(input("enter number"))
temp = n
rev = 0
181
while n > 0:
	rem = n % 10
	rev = rev * 10 + rem
	n = n // 10
if temp == rev:
	print(temp, " is Palindrom number")
else:
	print(temp, " is not Palindrom number")
