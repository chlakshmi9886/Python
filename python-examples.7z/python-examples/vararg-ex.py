def m(*x):
	print(x)

m(10,20,30)

m(4,3,21,1)
#internally var-args input will be stored like tuple.
