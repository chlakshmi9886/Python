import matplotlib.pyplot as plt
import seaborn as sns

df = sns.load_dataset("titanic")
print(df)