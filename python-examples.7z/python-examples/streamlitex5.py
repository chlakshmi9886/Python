import streamlit as st

btn = st.button("Submitted")

if btn:
	st.write("Details Submitted", btn)


with st.form("user_form details"):
	name=st.text_input("Enter user name")
	age = st.number_input("Enter your age",min_value=0)
	submitted=st.form_submit_button("Submit")
if submitted:
	st.write(f"Name:{name} and {age} years old")