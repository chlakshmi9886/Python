import streamlit as st
import datetime as dt

date_default = dt.date.today()

db = st.date_input("Select your date of birth ", date_default)

st.write(db)

time = st.time_input("Your meeting time is ")
st.write(time)