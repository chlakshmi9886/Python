#function examples

#function creation
def printfunction():
	print("Hello world using functions")

#function calling
p = printfunction()
print(p)

#create another function

def display():
	print("Display function")

display()
display()

def m1(a):
	print("M1 method", a)
	m2(a)

def m2(b):
	print("M2 method", b)
	

m1(10)
m2(20)

def m3(a, b):
	print("a and b values are ", a, b)


m3(10,20)

def addition(a,b):
	print("Sum of both values : ", (a+b))

addition(10,20)


def balance():
	print("Balance amount")
	return 1000

bal = balance();

if bal > 500:
	print("Full money")
elif bal > 300:
	print("Sufficient Money")
else:
	print("Less Moeny") 

print("balance amount is:", bal)


def mul():
	print("multiple values return function example")
	return 10, 20


a, b = mul()
print(a,"--------------",b)


def mul1():
	print("multiple values return function example")
	return 10, 20,3,40,4,50
x = mul1()
print(x)