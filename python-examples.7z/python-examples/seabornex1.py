import seaborn as sns

df = sns.load_dataset("titanic")

print(df)

df.info()

df.shape

df.columns