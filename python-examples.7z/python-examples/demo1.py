#about single line comment

print("Hello Python comments")

"""
Author: venkat
python programming
practice started
"""

print("multiline comment python program")

