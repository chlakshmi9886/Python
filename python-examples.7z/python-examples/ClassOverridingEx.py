class Animal:
	def sound(self):
		print("Some Sound")


class Wolf(Animal):
	def sound(self):
		print("Woof")

wolf = Wolf()
wolf.sound()

animal = Animal()
animal.sound()

animal_wolf = Wolf()
animal_wolf.sound()

class Dog:
	@staticmethod
	def info():
		print("Dogs are loyal animals")
	@classmethod
	def count(cls):
		print(f"There are many dogs of class {cls}")

dog = Dog()
dog.info()
dog.count()

