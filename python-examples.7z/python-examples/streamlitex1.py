import streamlit as st

st.write("Hello world")
st.write("Welcome to web development")