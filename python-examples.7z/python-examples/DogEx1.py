class DogEx:
	def __init__(self,name,age):
        	self._name=name#Conventionally private variable
        	self._age=age#Conventionally private variable
	@property
	def name(self):
        	return self._name
	@name.setter
	def name(self, value):
		self._name = value
	@property
	def age(self):
		return self._age
	@age.setter
	def age(self, value):
		if value < 0:
			print("Age can not be less than 0")
		else:
			self._age = value
	def __str__(self):
		return f"{self.name} is {self.age} years old"

	def setValue(self, new_value):
		self._age = new_value
        

dog = DogEx("Bunny",4)
print(dog)

dog.age = 5
dog.name="Sunny"
print(dog)
dog.setValue(9)
print(dog)