n = int(input("Enter number to check"))

print("Entered number is:: ",n)

if n % 2 == 0 :
	print(n, " is even Number")
else:
	print(n, " is odd number")

# odd or even using recursion

def check(n):
	if(n < 2):
		return n % 2 == 0
	return (check(n-2))
n=int(input("Enter another number"))
if(check(n) == True):
	print(n, " is even number")
else:
	print(n, " is odd number")


#using lambda function
check_num = lambda num: "even" if num %2 == 0 else "odd"
num=int(input("Enter another number"))
result = check_num(num)
print(num, "is an ", result, "number")
		