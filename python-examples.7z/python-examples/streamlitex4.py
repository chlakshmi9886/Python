import streamlit as st

age = st.slider("Enter your age range", 0, 100, (25,50))

st.write("Age", age)

rate_range = ["Bad", "Good", "Average", "Excellent"]

rate = st.select_slider("Rate your satisfaction", rate_range)
st.write("Your satisfaction ", rate)