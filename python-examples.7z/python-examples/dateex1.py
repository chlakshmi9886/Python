import datetime as dt

a = dt.date(2000,1,1)

print(a)

b  = dt.date.today()
print(b)