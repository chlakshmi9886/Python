import matplotlib.pyplot as plt

x=[4,81,25]
y=[2,9,5]
plt.title("It is a line chart")
plt.xlabel("square of a number")
plt.ylabel("number")
plt.plot(x,y,marker='*')
plt.show()