import streamlit as st
import pandas as pd
name = st.text_input("Enter your name")

st.write("Name is : ", name)

age = st.number_input("Enter your age",min_value=0,max_value=100,step=4)
st.write("Age is: ", age)

address = st.text_area("Enter your address")
st.write("Address is: ", address)

countriesList = ["India","US","China","Brazil","Russia"]
country = st.selectbox("Select your country from list",countriesList)
st.write("Country",country)

skilset = ["Java","Python","Jython","Cpython"]
skills = st.multiselect("Select your skills",skilset)
st.write("your skills are",skills)

gender = ["Male","Female"]
gender_val = st.radio("Please select Gender",gender)
st.write("Gender",gender_val)

df = pd.read_csv("sales11.csv")
st.write(df)

terms = st.checkbox("Accept Terms and Conditions")
st.write("Terms ",terms)